test_that("myncurve works", {
  result <- myncurve(2,3,2)
  expect_equal(result$mu, 2)         # Test if mu is correct
  expect_equal(result$sigma, 3)      # Test if sigma is correct
  expect_equal(result$a, 2)          # Test if a is correct

  # The area should be approximately
  expect_equal(result$area, 0.5, tolerance = 1e-4)
})
