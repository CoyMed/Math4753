#' Title
#'
#' @param x a vector of quantatative data
#'
#' @return a vector
#' @export
#'
#' @examples
#' mysquare(x = 1:10)
mysquare <- function(x){
  x^2
}
