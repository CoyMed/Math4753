#' @title Normal Curve Polygon
#'
#' @param mu Mean
#' @param sigma Standard Deviation
#' @param a X value of lower tail probability
#'
#' @return Makes a normal distribution plot with a polygon and its area
#' @export
#'
#' @examples
#' \dontrun{myncurve(2,5,3)}
myncurve = function(mu, sigma,a){
  x <- seq(mu - 4 * sigma, mu + 4 * sigma, length.out = 1000)
  curve(dnorm(x,mean=mu,sd=sigma), xlim = c(mu-3*sigma, mu + 3*sigma))
  list(mu = mu, sigma = sigma, a)

  xcurve = seq(mu-4*sigma, a,length=1000)
  ycurve = dnorm(xcurve,mean=mu,sd=sigma)
  polygon(c(mu-4*sigma,xcurve,a), c(0,ycurve,0), col="Blue")

  area = round(pnorm(a,mean=mu,sd=sigma),4)
  text(x=a,y=dnorm(a,mu,sigma)*0.75, paste("Area =", area, sep=""))

  return(list(mu=mu, sigma=sigma, a=a, area=area))
}
myncurve(10,20,10)
