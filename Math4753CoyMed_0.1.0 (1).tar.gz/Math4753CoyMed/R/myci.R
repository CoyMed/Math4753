#' @title myci
#'
#' @param x data
#'
#' @return 95% confidence interval of mean
#' @export
#'
#' @examples
#' \dontrun{myci(data)}
myci <- function(x){
  c(mean(x)-qt(1-0.05/2,length(x)-1)*sd(x)/sqrt(length(x)),
    mean(x)+qt(1-0.05/2,length(x)-1)*sd(x)/sqrt(length(x)))
}
