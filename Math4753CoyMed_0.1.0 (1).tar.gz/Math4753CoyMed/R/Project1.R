#' @title ntickets
#'
#' @param N Number of Seats
#' @param gamma Chance of Overbooking
#' @param p Chance of Showing up
#'
#' @return 2 graphs, one binomial, one normal of how many tickets can be sold without overbooking too much
#' @export
#'
#' @examples
#' \dontrun{ntickets(N=200,gamma=0.02,p=0.95)}
ntickets <- function(N,gamma,p){
# Range of n
  n<-N:(N+N/12)

  #Make plot surface
  layout(matrix(1:2, nrow = 2, ncol = 1))

  #Make Binomial Graph
  binomal = 1 - gamma - pbinom(N, n, p)
  plot(n, binomal, type = 'b', pch = 19, col = "blue", cex = 0.5, xlab = 'n',
       ylab = 'Objective', ylim = c(-0.1, 1.1))
  abline(h = 0, col = "red")

  amount <- which.min(abs(binomal))
  tickets <- (N-1) + amount

  # Vertical line
  abline(v = tickets, col = "red")
  # Title
  title(main = paste0('Objective vs. n to find optimal tickets sold \n
      (', tickets, '). gamma = ', gamma, sep = " ", 'N = ', N, sep = " ",
      'Discrete'), cex.main = 0.8)

  # Make Normal Graph
  x <- as.numeric(as.character(n))

  nomal <- function(n) {
    abs((N+1) - qnorm(1 - gamma, n*p, sqrt(n * p * (1 - p))))
  }
  curve(1 - gamma - pnorm(N + 0.5, mean = x * p, sd = (x * p * (1-p))^0.5), type = 'l',
        col = 'black', xlab = 'n', ylab = 'Objective', ylim = c(-0.15, 1.1), xlim = c(N, N + 30),
        cex = 0.6)

  abline(h = 0, col = "blue")

  # Optimize
  amount_n <- optimize(nomal, interval = c(N, 1000))
  tickets_n <- amount_n$minimum
  # Vertical line added

  abline(v = tickets_n, col = "blue")
  # Title
  title(main = paste0('Objective vs. n and Optimal Tickets \n (', tickets_n, ').
        gamma = ', gamma, sep = " ", 'N = ', N, sep = " ", 'normal'),cex.main = 0.7)

  list(nd = tickets, nc = tickets_n, N = N, gamma = gamma, p = p)

}
