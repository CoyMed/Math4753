#' @title myclt
#'
#' @param n Number of values created in each random sample
#' @param iter Iterations of uniform distribution ran
#' @param a Lower x lim
#' @param b Higher x lim
#'
#' @return It creates a histogram that shows the average sum of each sample
#' overlayed with the normal curve that can be approximated
#' @export
#'
#' @examples
#' \dontrun{myclt(n=10,iter=1000,a=0,b=5)}
myclt=function(n,iter,a=0,b=5){
  y=runif(n*iter,a,b)
  data=matrix(y,nrow=n,ncol=iter,byrow=TRUE)
  sm=apply(data,2,sum)
  h=hist(sm,plot=FALSE)
  hist(sm,col=rainbow(length(h$mids)),freq=FALSE,main="Distribution of the sum of uniforms")
  curve(dnorm(x,mean=n*(a+b)/2,sd=sqrt(n*(b-a)^2/12)),add=TRUE,lwd=2,col="Blue")
  sm
}
