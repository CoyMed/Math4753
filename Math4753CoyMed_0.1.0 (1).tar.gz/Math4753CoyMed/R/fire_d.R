#' Fire Dataset
#'
#' A dataset containing information about Distance and Damage.
#'
#' @docType data
#' @name fire
#' @usage data(fire)
#' @format A data frame with 15 rows and 2 variables:
#' \describe{
#'   \item{DISTANCE}{Distance Traveled}
#'   \item{DAMAGE}{Damage Done}
#' }
#' @source Canvas for Math4753
#'
"fire"
